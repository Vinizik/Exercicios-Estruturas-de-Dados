package mdc;

public class Node {

	public Node prox;

	public Node ant;

	public int dado;

	public Node(int dado) {

		this.dado = dado;

		this.prox = null;

		this.ant = null;

	}

}
